// priority: 0

onEvent('item.registry', event => {
	
	event.create('corn_flour').displayName('Corn Flour')
	
})

onEvent('block.registry', event => {
	//
})

/*
onEvent('fluid.registry', event => {

	event.create('diesel_fuel')
		.stillTexture('kubejs:block/diesel_fuel_still')
		.flowingTexture('kubejs:block/diesel_fuel_flow')
		.bucketColor(0x7A5E23)
		.noBlock()
		.displayName('Diesel')
  
	event.create('kerosene_fuel')
		.stillTexture('kubejs:block/kerosene_fuel_still')
    	.flowingTexture('kubejs:block/kerosene_fuel_flow')
		.bucketColor(0x3576A8)
		.noBlock()
		.displayName('Kerosene')
  
})
*/

onEvent('item.modification', event => {
	/*
	event.modify('minecraft:ender_pearl', item => {
		item.maxStackSize = 64
		item.fireResistant = true
	})
	*/
	event.modify('minecraft:potion', item => {
		item.maxStackSize = 16
	})
})

onEvent('block.modification', event => {
	/*
	event.modify('minecraft:stone', block => {
		block.destroySpeed = 0.1
		block.hasCollision = false
	})
	*/
})

onEvent('worldgen.remove', event => {	

	console.info("===== REMOVE ======")

	/*
	event.removeOres(ores => {
		ores.blocks = [ 'beyond_earth:moon_cheese_ore', 'mekanism:osmium_ore', 'mekanism:deepslate_osmium_ore', 'mekanism:uranium_ore', 'mekanism:deepslate_uranium_ore' ] // Removes coal and iron ore
		//ores.biomes.values = [ 'minecraft:plains' ] // Removes it only from plains biomes
	})
	*/

})

onEvent('worldgen.add', event => {
	console.info("===== ADD ======")	
})