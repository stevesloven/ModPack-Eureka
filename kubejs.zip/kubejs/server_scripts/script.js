// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	
	event.remove({output: 'minecraft:bread'})

	//items
	event.remove({output: 'createaddition:biomass_pellet'})
	event.remove({output: 'createaddition:furnace_burner'})
	event.remove({id: 'beyond_earth:steel_ingot_blasting'})

	event.remove({id: 'minecraft:cake'})
	event.remove({id: 'farmersdelight:pie_crust'})
	//event.remove({id: 'farmersdelight:sweet_berry_cheesecake'})
	//event.remove({id: 'farmersrespite:rose_hip_pie'})
	//event.remove({id: 'farmersrespite:coffee_cake'})
	
	event.remove({output: 'farmersdelight:wheat_dough'})
	event.remove({id: 'farmersdelight:bread_from_smelting'})
	event.remove({id: 'farmersdelight:bread_from_smoking'})

	//fluids
	event.remove({output: 'createaddition:bioethanol'})	
	event.remove({output: 'mekanismgenerators:bioethanol'})
	event.remove({id: 'beyond_earth:fuel_refining/fuel_from_oil'})

	event.remove({output: 'tconstruct:earth_cake'})

	event.remove({output: 'tconstruct:earth_cake'})
	event.remove({output: 'tconstruct:sky_cake'})
	event.remove({output: 'tconstruct:blood_cake'})
	event.remove({output: 'tconstruct:ender_cake'})
	event.remove({output: 'tconstruct:magma_cake'})

	event.remove({id: 'culturaldelights:corn_dough'})
	event.remove({id: 'culturaldelights:cooking/corn_dough'})
	
	event.remove({id: 'refinedstorage:quartz_enriched_iron'})

	event.remove({id: 'beyond_earth:fuel_refining/fuel_from_oil'})
	
	//items
	/*
	event.custom({
		"type": "create:compacting",
		"ingredients": [
			{
				"item": "mekanism:bio_fuel"
			}
		],
		"results": [
			{
				"fluid": "minecraft:water",
				"amount": 50
			},
			{
				"item": "createaddition:biomass_pellet",
				"count": 1
			}
		]
	})
	*/
	
	//fluids
	/*
	event.custom({
		"type": "create:mixing",
		"ingredients": [
			{
				"item": "minecraft:sugar"
			},
			{
				"item": "mekanism:bio_fuel"
			}
		],
		"results": [
			{
				"fluid": "createaddition:bioethanol",
				"amount": 100
			}
		]
	})

	event.custom({
		"type": "immersiveengineering:refinery",
 		"result": {
  			"fluid": "beyond_earth:fuel",
  			"amount": 16
 		},
 		"catalyst": {
  			"tag": "forge:dusts/sulfur"
 		},
 		"input0": {
  			"tag": "beyond_earth:oil",
  			"amount": 16
 		},
 		"input1": {
  			"tag": "forge:biodisel",
  			"amount": 32
 		},
 		"energy": 240
	})

	*/

	///////////////////////////////////////////////

	/*
	event.shaped('createaddition:furnace_burner', [
		' Z ',
		' F ',
		' B '
	], {
		Z: '#forge:ingots/bronze',
		F: 'minecraft:blast_furnace',
		B: 'createdeco:worn_bricks'
	})
	*/

})

onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})

onEvent('fluid.tags', event => {

	event.remove('beyond_earth:vehicle_fuel', 'immersiveengineering:biodiesel')	
	event.removeAll('minecraft:water')
	//event.removeAllTagsFrom('minecraft:water')

	event.add('minecraft:water', 'minecraft:water')
	event.add('forge:biodisel', 'immersiveengineering:biodiesel')

})