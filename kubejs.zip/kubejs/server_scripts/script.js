// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

//console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	
	// Vanilla
	event.remove({output: 'minecraft:bread', type: 'minecraft:crafting_shaped'})
	event.remove({id: 'minecraft:cake'})

	// Farmers Delight
	event.remove({output: 'farmersdelight:wheat_dough'})
	event.remove({id: 'farmersdelight:pie_crust'})
	event.remove({id: 'farmersdelight:sweet_berry_cheesecake'})
	event.remove({id: 'farmersrespite:rose_hip_pie'})
	event.remove({id: 'farmersrespite:coffee_cake'})
	event.remove({id: 'farmersdelight:bread_from_smelting'})
	event.remove({id: 'farmersdelight:bread_from_smoking'})

	event.remove({id: 'farmersdelight:cake_from_milk_bottle'})

	// Buddycards
	event.remove({id: 'buddycards:buddysteel_blend'})
	event.remove({id: 'buddycards:mystery_pack'})

	// Waystones
	event.remove({output: 'waystones:waystone'})
	event.remove({output: 'waystones:mossy_waystone'})
	event.remove({output: 'waystones:sandy_waystone'})
	event.remove({output: 'waystones:sharestone'})
	event.remove({output: 'waystones:portstone'})
	event.remove({output: 'waystones:warp_plate'}) // SPECIAL

	// MagnumTorch
	event.remove({output: 'magnumtorch:diamond_magnum_torch'})
	event.remove({output: 'magnumtorch:amethyst_magnum_torch'})
	event.remove({output: 'magnumtorch:emerald_magnum_torch'})

	// Create 

	event.remove({output: 'create:copper_backtank'})
	event.remove({output: 'create:potato_cannon'})
	event.remove({output: 'create:extendo_grip'})
	event.remove({output: 'create:wand_of_symmetry'})

	event.remove({output: 'create:display_link'})
	event.remove({output: 'create:steam_engine'})

	//'create:item_vault'
	//'create:track_station'
	//'create:display_board'

	event.remove({id: 'create:crafting/curiosities/cake'})

	// Create (deco)
	event.remove({output: 'createdeco:zinc_sheet'})
	event.replaceInput('createdeco:zinc_sheet', 'createaddition:zinc_sheet')

	// Create Crafts & Additions
	event.remove({mod: 'createaddition'})

	// The Eureka
	event.remove({output: 'eureka:base_battery'})
	event.remove({output: 'eureka:electric_heater'})

	// Alex Mobs
	event.remove({output: 'alexsmobs:blood_sprayer'})
	event.remove({output: 'alexsmobs:echolocator'})
	event.remove({output: 'alexsmobs:falconry_glove'})
	event.remove({output: 'alexsmobs:tarantula_hawk_elytra'})
	event.remove({output: 'alexsmobs:pupfish_locator'})
	event.remove({output: 'alexsmobs:flying_fish_boots'})
	event.remove({output: 'alexsmobs:void_worm_beak'})

	event.remove({output: 'alexsmobs:dimensional_carver'})
	event.remove({output: 'alexsmobs:hemolymph_blaster'})
	event.remove({output: 'alexsmobs:endolocator'})
	event.remove({output: 'alexsmobs:falconry_hood'})
	event.remove({output: 'alexsmobs:squid_grapple'})
	event.remove({output: 'alexsmobs:skelewag_sword'})
	event.remove({output: 'alexsmobs:void_worm_effigy'})
	event.remove({output: 'alexsmobs:rocky_chestplate'})
	event.remove({output: 'alexsmobs:vine_lasso'})

	event.remove({output: 'alexsmobs:shield_of_the_deep'})
	event.remove({output: 'alexsmobs:froststalker_helmet'})
	event.remove({output: 'alexsmobs:froststalker_helmet'})

	// Comforts
	event.remove({mod: 'comforts'})

	// Some Assembly
	event.remove({output: 'some_assembly_required:sandwiching_station'})

	// Sophisticated Backpacks
	event.remove({output: 'sophisticatedbackpacks:backpack'})
	event.remove({output: 'sophisticatedbackpacks:iron_backpack'})
	event.remove({output: 'sophisticatedbackpacks:gold_backpack'})
	event.remove({output: 'sophisticatedbackpacks:diamond_backpack'})
	event.remove({output: 'sophisticatedbackpacks:netherite_backpack'})

	// Trashcans
	event.remove({mod: 'trashcans'})

	// Toolbelt
	event.remove({mod: 'toolbelt'})

	// AppleTreesRev
	event.remove({id: 'appletreesrev:apple_sapling'})

	// Untitled Duckmod
	event.remove({id: 'untitledduckmod:crafting_shaped/duck_cake'})
	event.remove({id: 'untitledduckmod:crafting_shaped/goose_cake'})

	// BucketLib
	event.remove({id: 'bucketlib:cake'})

	// Ender Mail
	event.remove({output: 'endermail:locker'})
	event.remove({output: 'endermail:package_controller'})
	
	// Pretty Pipes
	event.remove({mod: 'prettypipes'})
	
})

onEvent('item.tags', event => {
	
	event.add('forge:custom_egg', 'untitledduckmod:duck_egg')
	event.add('forge:custom_egg', 'untitledduckmod:goose_egg')
	event.add('forge:custom_egg', 'alexsmobs:crocodile_egg')

	//

	event.add('sereneseasons:autumn_crops', 'appletreesrev:apple_sapling')
	event.add('sereneseasons:autumn_crops', 'minecraft:apple')

})

onEvent('tags.blocks', event => {
	
	event.add('sereneseasons:autumn_crops', 'appletreesrev:apple_sapling')
	//event.add('sereneseasons:autumn_crops', 'minecraft:apple')

})