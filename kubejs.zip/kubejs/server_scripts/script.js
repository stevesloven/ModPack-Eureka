// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

//console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	
	// Vanilla
	event.remove({output: 'minecraft:bread', type: 'minecraft:crafting_shaped'})
	event.remove({id: 'minecraft:cake'})

	// Farmers Delight
	event.remove({output: 'farmersdelight:wheat_dough'})
	event.remove({id: 'farmersdelight:pie_crust'})
	event.remove({id: 'farmersdelight:sweet_berry_cheesecake'})
	event.remove({id: 'farmersrespite:rose_hip_pie'})
	event.remove({id: 'farmersrespite:coffee_cake'})
	event.remove({id: 'farmersdelight:bread_from_smelting'})
	event.remove({id: 'farmersdelight:bread_from_smoking'})

	// Buddycards
	event.remove({id: 'buddycards:buddysteel_blend'})

	// Waystones
	event.remove({output: 'waystones:waystone'})
	event.remove({output: 'waystones:mossy_waystone'})
	event.remove({output: 'waystones:sandy_waystone'})
	event.remove({output: 'waystones:sharestone'})
	event.remove({output: 'waystones:portstone'})
	event.remove({output: 'waystones:warp_plate'}) // SPECIAL

	// MagnumTorch
	event.remove({output: 'magnumtorch:diamond_magnum_torch'})
	event.remove({output: 'magnumtorch:amethyst_magnum_torch'})
	event.remove({output: 'magnumtorch:emerald_magnum_torch'})

	// Create (deco)
	event.remove({output: 'createdeco:zinc_sheet'})
	event.replaceInput('createdeco:zinc_sheet', 'createaddition:zinc_sheet')

	// Create Crafts & Additions
	event.remove({mod: 'createaddition'})

	// The Eureka
	event.remove({output: 'eureka:base_battery'})
	event.remove({output: 'eureka:electric_heater'})

})

onEvent('item.tags', event => {
	
	//

})