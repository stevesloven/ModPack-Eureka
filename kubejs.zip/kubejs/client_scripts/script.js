// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

onEvent('jei.hide.items', event => {
	event.hide('createaddition:biomass')
	event.hide('mekanismgenerators:bioethanol_bucket')
	event.hide(Item.of('mekanism:creative_fluid_tank', '{mekData:{FluidTanks:[{Tank:0b,stored:{Amount:2147483647,FluidName:"mekanismgenerators:bioethanol"}}]}}'))
	//
	event.hide('titanium:block_test')
	event.hide('titanium:block_twenty_four_test')
	event.hide('titanium:block_asset_test')
	event.hide('titanium:machine_test')
	event.hide('titanium:creative_generator')
	//
	event.hide('immersiveengineering:dust_wood')
	event.hide('farmersdelight:wheat_dough')
})

onEvent('jei.hide.fluids', event => {
	event.hide('mekanismgenerators:bioethanol')
})