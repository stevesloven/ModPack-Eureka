// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

onEvent('jei.hide.items', event => {

	event.hide('farmersdelight:wheat_dough')
	event.hide('createdeco:zinc_sheet')


})